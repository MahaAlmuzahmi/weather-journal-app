// Setup empty JS object to act as endpoint for all routes
projectData = {};

// Require Express to run server and routes
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');


app.get('/', (req, res) => {
    res.send('weather journal app');
});

// Cors for cross origin allowance
app.use(cors());
/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


// Initialize the main project folder
app.use(express.static('website'));

// callback function to get '/all'
const getall= (req, res) => 
res.status(200).send(projectData);
// GET route 
app.get("/all",getall);

// callback function to post '/add'
const postData= (req, res) => {
    projectData=req.body;
    console.log(projectData);
    res.status(200).send(projectData);
}
// POST route 
app.post('/add',postData);


// Test server
const port = 7000;
app.get('/testserver', (req, res) => {
    res.send('Server is running');
});
  
// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
console.log('Server starting...');