/* Global Variables */

// The URL to retrieve weather information
const baseUrl = 'http://api.openweathermap.org/data/2.5/weather?zip=';
const apiKey = ',&appid=664c07498dc3b8d8c3c64da1e5aea046&units=metric'; 
const server="http://127.0.0.1:7000";

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.toDateString();

const generateData = () => { 
    //get value after click on the button
    const zip = document.getElementById("zip").value;
    const feelings = document.getElementById("feelings").value;
  
    // getWeatherData return promise
    getWeatherData(zip).then((data) => {

      if (data) {
        const {
          main: { temp },
          weather: [{ description }],
        } = data;
  
        const info = {
          newDate,
          temp: Math.round(temp), 
          feelings,
        };
  
        postData(server + "/add", info);
  
        updatingUI();
      }
    });
  };
  

//event listener for (generate) butn Click
document.getElementById('generate').addEventListener('click', generateData);


//Async function for get data
const getWeatherData = async (zip) => {
   

    try {
        const res = await fetch(baseUrl+zip+apiKey);
        const data =await res.json();
        if(data.cod !=200){
            error.innerHTML=data.message;
            setTimeout(_=> error.innerHTML = '',2000)
            throw `${data.message}`;
        }
    return data;
    } catch(error){
        console.log(error);
    }
};

// function to post data
const postData = async (url = "", info = {}) => {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(info),
    });
  
    try {
      const newData = await res.json();
      console.log(`You just saved`, newData);
      return newData;
    } catch (error) {
      console.log(error);
    }
  };
  
  //Function to GET Project Data updating UI 
  const updatingUI = async () => {
    const res = await fetch(server + "/all");
    try {
      const savedData = await res.json();
  
      document.getElementById("date").innerHTML = savedData.newDate;
      document.getElementById("temp").innerHTML = savedData.temp + '&degC';
      document.getElementById("content").innerHTML = savedData.feelings;
    } catch (error) {
      console.log(error);
    }
  };